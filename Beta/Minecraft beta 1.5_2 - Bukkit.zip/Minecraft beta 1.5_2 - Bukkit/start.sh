#!/bin/bash
cd "$(dirname "$0")"
screen -S minecraft_server -d -m java -Xmx1G -Xms1G -jar craftbukkit.jar
